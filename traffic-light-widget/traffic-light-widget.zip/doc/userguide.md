## Introduction

Visualize a single boolean value using a red (`false`) or green (`true`) circle

## Settings

- `Description (false)`: Description to display if input is false
- `Description (true)`: Description to display if input is true

## Wiring

### Input Endpoints

- `Boolean`: Input value to visualize